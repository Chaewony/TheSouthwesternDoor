using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BonusSlider : MonoBehaviour
{
    /*private ScoreCounter bonus_counter = null;

    public BonusSlider bonusSlider;
    float fillBonusSlider;
    
    // Start is called before the first frame update
    void Start()
    {
        bonusSlider = GetComponent<BonusSlider>();
        bonus_counter = gameObject.GetComponent<ScoreCounter>();
    }

    // Update is called once per frame
    void Update()
    {
        if(this.bonus_counter.updateBonusGage() == 0)
        {
            transform.Find("Fill Area").gameObject.SetActive(false);
            bonusSlider.
        }
        else
            transform.Find("Fill Area").gameObject.SetActive(true);
    }*/
}
